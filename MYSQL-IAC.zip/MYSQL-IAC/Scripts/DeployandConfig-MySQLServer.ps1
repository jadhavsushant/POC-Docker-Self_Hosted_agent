
Param(

    [string] $settingsFileName = '\Settings\mysqlserverinputfile.json',
    [string] $armDeploymentTemplateFile = '\Templates\MySQLARMtemplate.json',
	[boolean] $unitTestMode = $false
)
#Check no missing setting
function Test-ParameterSet
{
    param
    (
        [parameter(Mandatory = $true)][System.Object]$settings
    )
    # Loop through the $settings and check no missing setting
    if ($null -eq $applicationFileJson.subscriptions) {throw "Missing subscriptions field in settings file"}
    foreach ($subscription in $applicationFileJson.subscriptions)
    {
        if ($null -eq $subscription.subscriptionId) {throw "Missing subscription Id field in settings file"}
        # Loop through the $settings and check no missing setting
        foreach ($vault in $settings.WorkLoads)
        {
		    if ($null -eq $vault.applicationName) {throw "Missing applicationName in settings file for $($subscription.subscriptionId)"}
            if ($null -eq $vault.environmentName) {throw "Missing environmentName in settings file for $($subscription.subscriptionId)"}
			if ($null -eq $vault.resourceGroupName) {throw "Missing resourceGroupName in settings file for $($subscription.subscriptionId)"}
            if ($null -eq $vault.MySQLServerName) {throw "Missing serverName in settings file for $($subscription.subscriptionId)"} 
            if ($null -eq $vault.MySQLServerLogin) {throw "Missing serverLogin Name in settings file for $($subscription.subscriptionId)"}
            if ($null -eq $vault.keyvaultName) {throw "Missing keyvaultName in settings file for $($subscription.subscriptionId)"}
			if ($null -eq $vault.skuTier) {throw "Missing skuTier in settings file for $($subscription.subscriptionId)"}
			if ($null -eq $vault.skuCapacity) {throw "Missing skuCapacity in settings file for $($subscription.subscriptionId)"}
			if ($null -eq $vault.MySQLVersion) {throw "Missing MySQLVersion in settings file for $($subscription.subscriptionId)"}
			if ($null -eq $vault.StorageSizeMB) {throw "Missing StorageSizeMB in settings file for $($subscription.subscriptionId)"}
			if ($null -eq $vault.backupRetentionDays) {throw "Missing backupRetentionDays in settings file for $($subscription.subscriptionId)"}
			if ($null -eq $vault.geoRedundantBackup) {throw "Missing geoRedundantBackup in settings file for $($subscription.subscriptionId)"}
			if ($null -eq $vault.enableVnetIntegration) {throw "Missing enableVnetIntegration in settings file for $($subscription.subscriptionId)"}
			if ($null -eq $vault.ipRestriction) {throw "Missing ipRestriction in settings file for $($subscription.subscriptionId)"}
            if ($null -eq $vault.cmk) {throw "Missing cmk in settings file for $($subscription.subscriptionId)"}
            if ($null -eq $vault.enableaadauth) {throw "Missing enableaadauth in settings file for $($subscription.subscriptionId)"}
		 if ($vault.ipRestriction -eq "enabled")
		 {
			if ($null -eq $vault.startIP) {throw "Missing startIP in settings file for $($subscription.subscriptionId)"}
			if ($null -eq $vault.endIP) {throw "Missing endIP in settings file for $($subscription.subscriptionId)"}
		 }
		 if($vault.enableVnetIntegration -eq "Enabled")
		 {
			if ($null -eq $vault.virtualNetworkRGName) {throw "Missing virtualNetworkRGName in settings file for $($subscription.subscriptionId)"}  
			if ($null -eq $vault.virtualNetworkName) {throw "Missing virtualNetworkName in settings file for $($subscription.subscriptionId)"}  
			if ($null -eq $vault.subnetName) {throw "Missing subnetName in settings file for $($subscription.subscriptionId)"} 
		 } 
         $backupRetentionDaysCheck = [int] $vault.backupRetentionDays
         if (! ($backupRetentionDaysCheck -ge 7 -and $num -le 35))
		 {
			throw "Valid backupRetentionDays in days must be between 7 and 35 in settings file for $($subscription.subscriptionId)"
			
		 }
         if($vault.cmk -eq "enable")
		 {
			if ($null -eq $vault.cmkkeyvaultname) {throw "Missing cmkkeyvaultname in settings file for $($subscription.subscriptionId)"}  
            if ($null -eq $vault.cmkkeyvaultRGName) {throw "Missing cmkkeyvaultRGName in settings file for $($subscription.subscriptionId)"}  
			if ($null -eq $vault.keyname) {throw "Missing keyname in settings file for $($subscription.subscriptionId)"}  
			if ($null -eq $vault.KeyVersion) {throw "Missing KeyVersion in settings file for $($subscription.subscriptionId)"} 
		 }
         if($vault.enableaadauth -eq "enable")
		 {
			if ($null -eq $vault.aadadminname) {throw "Missing aadadminname in settings file for $($subscription.subscriptionId)"}  
            if ($null -eq $vault.aadadminobjectid) {throw "Missing aadadminobjectid in settings file for $($subscription.subscriptionId)"}  
		 }
              	
		} # MySQLServer
    } # Subscription
    return $true
} # Function


function Publish-MySQLServer
{
    [OutputType([String])]
    param
    (
        [parameter(Mandatory = $true)][string]$armDeploymentTemplateFile,
        [parameter(Mandatory = $true)][string]$resourceGroupName,
        [parameter(Mandatory = $true)][string]$MySQLServerName,
		[parameter(Mandatory = $true)][string]$MySQLServerLogin,
        [parameter(Mandatory = $true)][string]$location,
		[parameter(Mandatory = $true)][string]$keyvaultName,
		[parameter(Mandatory = $true)][string]$skuTier,
		[parameter(Mandatory = $true)][int]$skuCapacity,
		[parameter(Mandatory = $true)][string]$MySQLVersion,
		[parameter(Mandatory = $true)][int]$StorageSizeMB,
		[parameter(Mandatory = $true)][int]$backupRetentionDays,
		[parameter(Mandatory = $true)][string]$geoRedundantBackup,
		[parameter(Mandatory = $true)][string]$ipRestriction,
		[parameter(Mandatory = $true)][string]$startIP,
		[parameter(Mandatory = $true)][string]$endIP,
		[parameter(Mandatory = $true)][string]$enableVnetIntegration,
		[parameter(Mandatory = $true)][string]$virtualNetworkRGName,
		[parameter(Mandatory = $true)][string]$virtualNetworkName,
		[parameter(Mandatory = $true)][string]$subnetName,
        [parameter(Mandatory = $true)][string]$subscriptionId,
        [parameter(Mandatory = $true)][string]$cmk,
        [parameter(Mandatory = $false)][string]$keyname,
        [parameter(Mandatory = $false)][string]$KeyVersion,
        [parameter(Mandatory = $false)][string]$cmkkeyvaultRGName,
        [parameter(Mandatory = $false)][string]$cmkkeyvaultname,
        [parameter(Mandatory = $true)][string]$enableaadauth,
        [parameter(Mandatory = $false)][string]$aadadminname,
        [parameter(Mandatory = $false)][string]$aadadminobjectid
    )

   #Check resource group exist
    try {
        $resourceGroup = Get-AzResourceGroup -Name $resourceGroupName -ErrorAction Stop   
    }
    catch {
        $resourceGroup = $null
    }
    if ($null -eq $resourceGroup)
    {
        $message = "Resource group $resourceGroupName not found, deployment stop"
        Write-Verbose $message
        return $message
    }	
	    else 
    {
        # Prepare deployment variables
		Write-Verbose "ResourceGroup Found"

        #Password Generation
        Do {
        $pass = $(([char[]]([char]65..[char]90) + ([char[]]([char]97..[char]122)) + 0..9 | Sort-Object {Get-Random})[0..13] -join '')
        } # End of 'Do'
         Until (($pass -cmatch "[A-Z\p{Lu}\s]") -and ($pass -cmatch "[a-z\p{Ll}\s]") -and ($pass -match "[\d]"))

        $Password = ConvertTo-SecureString -String $pass -AsPlainText -Force							  
       
        if($enableVnetIntegration -eq 'Enabled')
        {
        $vnet=Get-AzVirtualNetwork -Name $virtualNetworkName -ResourceGroupName $virtualNetworkRGName -WarningAction Ignore

			$VirtualNetwork = $vnet |  Get-AzVirtualNetworkSubnetConfig -Name $subnetName -WarningAction Ignore
            $subnetAddressPrefix = [string]$VirtualNetwork.AddressPrefix
            Write-Verbose $subnetAddressPrefix
            $nsgId = $VirtualNetwork.NetworkSecurityGroup.Id
            $rtId = $VirtualNetwork.RouteTable.Id
            $delg = $VirtualNetwork.Delegations
            $endPnt = $virtualNetwork.ServiceEndpoints.Service

               if ($endPnt -notcontains "Microsoft.Sql")
               {
                 Write-Verbose "Started Integrating with Vnet Endpoint"
				#Get existing service endpoints
				$ServiceEndPoint = New-Object 'System.Collections.Generic.List[String]'
				$VirtualNetwork.ServiceEndpoints | ForEach-Object { $ServiceEndPoint.Add($_.service) }
				$ServiceEndPoint.Add("Microsoft.Sql")

				$vnetSerEndpoint = $vnet | Set-AzVirtualNetworkSubnetConfig -Name $subnetName -AddressPrefix $subnetAddressPrefix -ServiceEndpoint $ServiceEndPoint -NetworkSecurityGroupId $nsgId -RouteTableId $rtId -Delegation $delg -WarningAction Ignore | Set-AzVirtualNetwork -WarningAction Ignore
               }
               else
               {
                Write-Verbose "$virtualNetworkName has already configured with an endpoint Microsoft.Sql"
               }
        }
        else
        {
          $subnetAddressPrefix = "null"
        }

        $MySqlServerdeploy= @{}
		$MySqlServerdeploy.Add('MySQLServerName', $MySQLServerName)
		$MySqlServerdeploy.Add('MySQLServerLogin', $MySQLServerLogin)
		$MySqlServerdeploy.Add('MySQLServerPassword', $Password)
        $MySqlServerdeploy.Add('location', $location)
		$MySqlServerdeploy.Add('skuTier', $skuTier)
		$MySqlServerdeploy.Add('skuCapacity', $skuCapacity)
		$MySqlServerdeploy.Add('MySQLVersion', $MySQLVersion)
		$MySqlServerdeploy.Add('StorageSizeMB', $StorageSizeMB)
		$MySqlServerdeploy.Add('backupRetentionDays', $backupRetentionDays)
		$MySqlServerdeploy.Add('geoRedundantBackup', $geoRedundantBackup)
		$MySqlServerdeploy.Add('ipRestriction', $ipRestriction)
		$MySqlServerdeploy.Add('startIP', $startIP)
		$MySqlServerdeploy.Add('endIP', $endIP)
		$MySqlServerdeploy.Add('enableVnetIntegration', $enableVnetIntegration)
		$MySqlServerdeploy.Add('virtualNetworkRGName', $virtualNetworkRGName)
		$MySqlServerdeploy.Add('virtualNetworkName', $virtualNetworkName)
		$MySqlServerdeploy.Add('subnetName', $subnetName)
        $MySqlServerdeploy.Add('subnetAddressPrefix', $subnetAddressPrefix)
        $MySqlServerdeploy.Add('cmk', $cmk)
        $MySqlServerdeploy.Add('cmkkeyvaultRGName',$cmkkeyvaultRGName)
        $MySqlServerdeploy.Add('cmkkeyvaultname',$cmkkeyvaultname)
        $MySqlServerdeploy.Add('keyname',$keyname)
        $MySqlServerdeploy.Add('KeyVersion',$KeyVersion)
        $MySqlServerdeploy.Add('enableaadauth',$enableaadauth)
        $MySqlServerdeploy.Add('aadadminname',$aadadminname)
        $MySqlServerdeploy.Add('aadadminobjectid',$aadadminobjectid)

		$deploymentParameters = $MySqlServerdeploy
     
	    #Unlock ResourceGroup
		Unlock-ResourceGroup $resourceGroupName
        Write-Verbose "ResourceGroup Unlocked"

		       $armDeployment = New-AzResourceGroupDeployment -Name ((Get-ChildItem $armDeploymentTemplateFile).BaseName + '-' + ((Get-Date).ToUniversalTime()).ToString('yyyyMMdd-HHmm')) `
                                            -ResourceGroupName $resourceGroupName `
                                            -TemplateFile $armDeploymentTemplateFile `
                                            -TemplateParameterObject $deploymentParameters `
                                            -Force -Verbose
        
		Write-Verbose "Deployment on rg $($armDeployment.ResourceGroupName) $($armDeployment.ProvisioningState) $($armDeployment.Timestamp)"
        if($armDeployment.ProvisioningState -eq 'Succeeded')
        {
            
            $deny=(Get-AzKeyVault -VaultName $keyvaultName).NetworkAcls.DefaultAction
            if($deny -eq "Deny" )
            {
                    Add-AzKeyVaultNetworkRule -VaultName $keyvaultName -VirtualNetworkResourceId "/subscriptions/02277fc5-a6c3-4631-9556-a586800e1675/resourceGroups/rg-network-prd-westeurope-02/providers/Microsoft.Network/virtualNetworks/vnetprv-network-prd-westeurope-02/subnets/netprv-vsts-prd-westeurope-02"
            }
       
		$secret = Set-AzKeyVaultSecret -VaultName $keyvaultName `
                                          -Name "$MySQLServerName-adminpwd"  `
                                          -SecretValue $Password `
                                          -ContentType 'Admin Password of MySQLServer' -ErrorAction Stop 
		 if($null -ne $secret)
        {
            Write-Verbose "password stored in $keyvaultName"
        }	
            if($deny -eq "Deny" )
            {
                    Remove-AzKeyVaultNetworkRule -VaultName $keyvaultName -VirtualNetworkResourceId "/subscriptions/02277fc5-a6c3-4631-9556-a586800e1675/resourceGroups/rg-network-prd-westeurope-02/providers/Microsoft.Network/virtualNetworks/vnetprv-network-prd-westeurope-02/subnets/netprv-vsts-prd-westeurope-02"
            }
        }


        #Lock ResourceGroup
        Lock-ResourceGroup $resourceGroupName
        Write-Verbose "ResourceGroup Locked"

        return $armDeployment.ProvisioningState
	}			
}		
		
		


function Publish-Infrastructure
{
param(
        [parameter(Mandatory = $true)][string]$settingsFileName,
        [parameter(Mandatory = $true)][string]$armDeploymentTemplateFile
        
     )
 
    $settings = Get-JsonParameterSet -settingsFileName $settingsFileName
	$deploymentIsSucceeded = $true
    $workloadCount = $settings.WorkLoads.Count
    Write-Verbose "workloadCounts: $workloadCount"
    if($workloadCount -ge 1)
	{
        for($i = 0;$i -lt $workloadCount; $i++)
            { 
               $applicationName = $settings.WorkLoads[$i].applicationName
               $environmentName = $settings.WorkLoads[$i].environmentName
			
                $applicationFile = "..\SettingsByWorkload\" + "nv_" + $applicationName + ".workload.json"
                $applicationFile = Get-FileFullPath -fileName $applicationFile  -rootPath $PSScriptRoot
                $applicationFileJson = Get-JsonParameterSet -settingsFileName $applicationFile
                $null = Test-ParameterSet -settings $settings
                $policyCount = $applicationFileJson.subscriptions.Count
                if($policyCount -ge 1)
                {  
                    for($j = 0;$j -lt $policyCount; $j++)
                    { 
                        if($applicationFileJson.subscriptions[$j].environmentName -eq $environmentName)
                        {
                            $subscriptionId = $applicationFileJson.subscriptions[$j].subscriptionId 
                            Write-Verbose "Environment Subscription: $($subscriptionId)"
                            Set-ContextIfNeeded -SubscriptionId $subscriptionId
                            foreach ($mysql in $settings.WorkLoads[$i])
                            {
								$resourceGroupName = $mysql.resourceGroupName
								$MySQLServerName = $mysql.MySQLServerName
								$MySQLServerLogin = $mysql.MySQLServerLogin
                                $location = $mysql.location
                                $keyvaultName = $mysql.keyvaultName
                                $skuTier = $mysql.skuTier
								$skuCapacity = $mysql.skuCapacity
								$MySQLVersion = $mysql.MySQLVersion
								$StorageSizeMB = $mysql.StorageSizeMB
								$backupRetentionDays = $mysql.backupRetentionDays
								$geoRedundantBackup = $mysql.geoRedundantBackup
							$ipRestriction = $mysql.ipRestriction
							if($ipRestriction -eq "disabled")
							{
								$startIP = "null"
								$endIP = "null"
							}
							else
							{
								$startIP = $mysql.startIP
								$endIP = $mysql.endIP
							}
							
							$enableVnetIntegration = $mysql.enableVnetIntegration
							if($enableVnetIntegration -eq "Disabled")
							{
								$virtualNetworkRGName = "null"
								$virtualNetworkName = "null"
								$subnetName = "null"
							}
							else
							{
								$virtualNetworkRGName = $mysql.virtualNetworkRGName
								$virtualNetworkName = $mysql.virtualNetworkName
								$subnetName = $mysql.subnetName
							}

                            $cmk = $mysql.cmk
							if($cmk -eq "enable")
							{
								   $keyname = $mysql.keyname
                                   $KeyVersion = $mysql.KeyVersion
                                   $cmkkeyvaultRGName = $mysql.cmkkeyvaultRGName
                                   $cmkkeyvaultname = $mysql.cmkkeyvaultname
							}
							else
							{
								   $keyname = "null"
                                   $KeyVersion = "null"
                                   $cmkkeyvaultRGName = "null"
                                   $cmkkeyvaultname = "null"
							}
                            $enableaadauth = $mysql.enableaadauth
                            if($enableaadauth -eq "enable")
							{
								   $aadadminname = $mysql.aadadminname
                                   $aadadminobjectid = $mysql.aadadminobjectid
							}
							else
							{
								   $aadadminname = "null"
                                   $aadadminobjectid = "null"
							}

                                #$connectionPolicyType = $sql.connectionPolicyType 
								  
                                Write-Verbose ""
                                Write-Verbose "Ready to start deployment of a MySQLServer $MySQLServerName on environment $EnvironmentName in subscription $subscriptionId for resource group: $resourceGroupName"
                
                                $result = Publish-MySQLServer `
                                -armDeploymentTemplateFile $armDeploymentTemplateFile `
                                -resourceGroupName $resourceGroupName `
								-MySQLServerName $MySQLServerName `
								-MySQLServerLogin $MySQLServerLogin `
                                -location $location `
								-skuTier $skuTier `
								-skuCapacity $skuCapacity `
								-MySQLVersion $MySQLVersion `
								-StorageSizeMB $StorageSizeMB `
								-backupRetentionDays $backupRetentionDays `
								-geoRedundantBackup $geoRedundantBackup `
                                -keyvaultName $keyvaultName `
								-ipRestriction $ipRestriction `
								-startIP $startIP `
								-endIP $endIP `
								-enableVnetIntegration $enableVnetIntegration `
								-virtualNetworkRGName $virtualNetworkRGName `
								-virtualNetworkName $virtualNetworkName `
								-subnetName $subnetName `
                                -cmk $cmk `
                                -keyname $keyname `
                                -KeyVersion $KeyVersion `
                                -cmkkeyvaultRGName $cmkkeyvaultRGName `
                                -cmkkeyvaultname $cmkkeyvaultname `
                                -enableaadauth $enableaadauth `
                                -aadadminname $aadadminname `
                                -aadadminobjectid $aadadminobjectid `
                                -subscriptionId $subscriptionId
		
                                if ($result -ne 'Succeeded') {$deploymentIsSucceeded = $false}
                               
                            }
                        }
                    }
                }
            }
    }
    if ($deploymentIsSucceeded -eq $false)  
    {
        $errorID = 'Deployment failure'
        $errorCategory = [System.Management.Automation.ErrorCategory]::LimitsExceeded
        $errorMessage = 'Deployment failed'
        $exception = New-Object -TypeName System.SystemException -ArgumentList $errorMessage
        $errorRecord = New-Object -TypeName System.Management.Automation.ErrorRecord -ArgumentList $exception,$errorID, $errorCategory, $null
        Throw $errorRecord
    }
    else 
    {
        return $true    
    } # Deploy status
}


if ($unitTestMode)
{
    #do nothing
    Write-Verbose 'Unit test mode, no deployment' -Verbose
}
else 
{
    #Log in Azure if not already done
    try 
    {
        $AzContext = Get-AzContext -ErrorAction Stop
    }
    catch 
    {
        $result = Connect-AzAccount
        $azureAzContext = $result.Context
    }
    Write-Verbose "Subscription name $($azureAzContext.Subscription.Name)" -Verbose
    $VerbosePreference = 'Continue'

    # Get required templates and setting files. Throw if not found
    $scriptsPath = $PSScriptRoot

    for ($x=1; $x -lt 2 ; $x++) 
    {
    $scriptsPath = Split-Path -Path $scriptsPath -Parent  
    }
    $settingsFileName = Join-Path $scriptsPath $settingsFileName
    $armDeploymentTemplateFile = Join-Path $scriptsPath $armDeploymentTemplateFile
	
	Write-Verbose "Full Path of MySQLServerInputSettings File: $settingsFileName" -Verbose
	Write-Verbose "Full Path of MySQLServerArmTemplate File: $armDeploymentTemplateFile" -Verbose

	 return Publish-Infrastructure `
        -settingsFileName $settingsFileName `
        -armDeploymentTemplateFile $armDeploymentTemplateFile
}